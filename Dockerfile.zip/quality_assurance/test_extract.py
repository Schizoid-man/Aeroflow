"""Unit tests for pipeline.extract."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from pipeline import extract
from pipeline.iot_stream import generate_synthetic_readings


def test_synthetic_readings_shape():
    df = generate_synthetic_readings(count=15)
    assert len(df) == 15
    assert {"recorded_at", "device_id", "temperature_c"}.issubset(df.columns)


def test_csv_loads_correctly(tmp_path: Path):
    sample_path = tmp_path / "sample_iot.csv"
    generate_synthetic_readings(count=5).to_csv(sample_path, index=False)
    df = extract.extract_from_csv(sample_path)
    assert len(df) == 5
    assert "battery_pct" in df.columns


def test_run_extraction_uses_csv(tmp_path: Path):
    sample_path = tmp_path / "sample_iot.csv"
    generate_synthetic_readings(count=8).to_csv(sample_path, index=False)
    df = extract.run_extraction(
        dry_run=True, use_mqtt=False, csv_path=sample_path
    )
    assert len(df) == 8
    assert "site" in df.columns
