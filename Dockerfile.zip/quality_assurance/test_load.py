"""Unit tests for pipeline.load."""

from __future__ import annotations

import pandas as pd

from pipeline import load


def test_table_creation(monkeypatch, tmp_path):
    df_raw = pd.DataFrame(
        [
            {
                "recorded_at": "2025-01-01T00:00:00Z",
                "device_id": "device-01",
                "site": "Plant-1",
                "temperature_c": 22.0,
                "humidity": 55.0,
                "pm2_5": 12.0,
                "co_ppm": 0.5,
                "vibration": 0.2,
                "battery_pct": 80.0,
                "source": "csv",
            }
        ]
    )
    df_proc = pd.DataFrame(
        [
            {
                "recorded_at": "2025-01-01 00:00:00",
                "site": "Plant-1",
                "temperature_c": 22.0,
                "humidity": 55.0,
                "pm2_5": 12.0,
                "co_ppm": 0.5,
                "vibration": 0.2,
                "battery_pct": 80.0,
                "temp_category": "Normal",
                "hour_of_day": 0,
                "day_of_week": 0,
                "rolling_avg_temp_7d": 22.0,
                "temperature_c_norm": 0.0,
                "humidity_norm": 0.0,
                "pm2_5_norm": 0.0,
                "co_ppm_norm": 0.0,
                "vibration_norm": 0.0,
                "battery_pct_norm": 0.0,
            }
        ]
    )

    class DummyBegin:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def execute(self, *args, **kwargs):
            return None

    class DummyEngine:
        def begin(self):
            return DummyBegin()

    eng = DummyEngine()

    monkeypatch.setattr(load, "ensure_tables", lambda *a, **k: None)

    calls = {"to_sql": 0}

    def fake_to_sql(self, *args, **kwargs):
        calls["to_sql"] += 1

    monkeypatch.setattr(pd.DataFrame, "to_sql", fake_to_sql, raising=True)

    load.load_raw_and_processed(raw_df=df_raw, processed_df=df_proc, engine=eng)
    assert calls["to_sql"] == 2


def test_row_count_logged(monkeypatch, caplog):
    df = pd.DataFrame([{"a": 1}, {"a": 2}])

    class DummyEngine:
        pass

    called = {"to_sql": False}

    def fake_to_sql(*args, **kwargs):
        called["to_sql"] = True

    monkeypatch.setattr(pd.DataFrame, "to_sql", fake_to_sql, raising=True)
    caplog.set_level("INFO")
    rows = load.load_dataframe(engine=DummyEngine(), df=df, table_name="x")
    assert called["to_sql"]
    assert rows == 2
    assert any("Inserted 2 rows" in rec.message for rec in caplog.records)
