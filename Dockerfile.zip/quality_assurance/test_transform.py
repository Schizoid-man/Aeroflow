"""Unit tests for pipeline.transform."""

from __future__ import annotations

import pandas as pd

from pipeline.transform import run_transformation


def test_nulls_removed():
    df = pd.DataFrame(
        [
            {
                "recorded_at": "2025-01-01",
                "site": "X",
                "temperature_c": 22,
                "humidity": 55,
                "pm2_5": 10,
                "co_ppm": 0.5,
                "vibration": 0.2,
                "battery_pct": 80,
            },
            {
                "recorded_at": "2025-01-02",
                "site": "X",
                "temperature_c": None,
                "humidity": 50,
                "pm2_5": 12,
                "co_ppm": 0.6,
                "vibration": 0.3,
                "battery_pct": 79,
            },
        ]
    )
    out = run_transformation(df)
    assert len(out) == 1


def test_temperature_categories_correct():
    df = pd.DataFrame(
        [
            {
                "recorded_at": "2025-01-01 00:00:00",
                "site": "X",
                "temperature_c": 16,
                "humidity": 50,
                "pm2_5": 10,
                "co_ppm": 0.4,
                "vibration": 0.2,
                "battery_pct": 80,
            },
            {
                "recorded_at": "2025-01-02 00:00:00",
                "site": "X",
                "temperature_c": 30,
                "humidity": 60,
                "pm2_5": 12,
                "co_ppm": 0.6,
                "vibration": 0.3,
                "battery_pct": 75,
            },
        ]
    )
    out = run_transformation(df)
    cats = list(out["temp_category"].values)
    assert "Cool" in cats
    assert "Hot" in cats


def test_normalized_values_in_range():
    df = pd.DataFrame(
        [
            {
                "recorded_at": "2025-01-01",
                "site": "X",
                "temperature_c": 20,
                "humidity": 55,
                "pm2_5": 5,
                "co_ppm": 0.4,
                "vibration": 0.1,
                "battery_pct": 90,
            },
            {
                "recorded_at": "2025-01-02",
                "site": "X",
                "temperature_c": 25,
                "humidity": 65,
                "pm2_5": 15,
                "co_ppm": 0.7,
                "vibration": 0.3,
                "battery_pct": 70,
            },
        ]
    )
    out = run_transformation(df)
    norm_cols = [c for c in out.columns if c.endswith("_norm")]
    assert norm_cols
    assert (out[norm_cols] >= 0).all().all()
    assert (out[norm_cols] <= 1).all().all()


def test_rolling_avg_computed():
    rows = []
    for i in range(10):
        rows.append(
            {
                "recorded_at": f"2025-01-{i + 1:02d}",
                "site": "X",
                "temperature_c": 20 + i,
                "humidity": 55,
                "pm2_5": 10,
                "co_ppm": 0.5,
                "vibration": 0.2,
                "battery_pct": 80,
            }
        )
    df = pd.DataFrame(rows)
    out = run_transformation(df)
    assert "rolling_avg_temp_7d" in out.columns
    assert out["rolling_avg_temp_7d"].isna().sum() == 0
