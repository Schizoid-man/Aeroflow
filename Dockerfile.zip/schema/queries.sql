-- Sample analytical queries for IoT reporting

-- 1) Site-wise average temperature
SELECT site, AVG(temperature_c) AS avg_temperature_c
FROM processed_iot_readings
GROUP BY site
ORDER BY avg_temperature_c DESC;

-- 2) Temperature category distribution
SELECT temp_category, COUNT(*) AS records
FROM processed_iot_readings
GROUP BY temp_category
ORDER BY records DESC;

-- 3) Weekly pattern: average temperature by day_of_week
SELECT day_of_week, AVG(temperature_c) AS avg_temperature_c
FROM processed_iot_readings
GROUP BY day_of_week
ORDER BY day_of_week;

-- 4) Trend: daily average PM2.5 by site
SELECT site, DATE(recorded_at) AS day, AVG(pm2_5) AS avg_pm25
FROM processed_iot_readings
GROUP BY site, DATE(recorded_at)
ORDER BY site, day;
