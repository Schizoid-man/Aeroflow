/*
SCHEMA DIAGRAM (PostgreSQL)

raw_iot_readings
  - id SERIAL PRIMARY KEY
  - recorded_at TIMESTAMP
  - device_id TEXT
  - site TEXT
  - temperature_c FLOAT
  - humidity FLOAT
  - pm2_5 FLOAT
  - co_ppm FLOAT
  - vibration FLOAT
  - battery_pct FLOAT
  - source TEXT
  - ingested_at TIMESTAMP DEFAULT NOW()

processed_iot_readings
  - id SERIAL PRIMARY KEY
  - recorded_at TIMESTAMP
  - site TEXT
  - temperature_c FLOAT
  - humidity FLOAT
  - pm2_5 FLOAT
  - co_ppm FLOAT
  - vibration FLOAT
  - battery_pct FLOAT
  - temp_category TEXT
  - hour_of_day INT
  - day_of_week INT
  - rolling_avg_temp_7d FLOAT
  - temperature_c_norm FLOAT
  - humidity_norm FLOAT
  - pm2_5_norm FLOAT
  - co_ppm_norm FLOAT
  - vibration_norm FLOAT
  - battery_pct_norm FLOAT
  - processed_at TIMESTAMP DEFAULT NOW()

Relationships:
  - None enforced (ETL appends both tables independently).
*/

CREATE TABLE IF NOT EXISTS raw_iot_readings (
  id SERIAL PRIMARY KEY,
  recorded_at TIMESTAMP,
  device_id TEXT,
  site TEXT,
  temperature_c FLOAT,
  humidity FLOAT,
  pm2_5 FLOAT,
  co_ppm FLOAT,
  vibration FLOAT,
  battery_pct FLOAT,
  source TEXT,
  ingested_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS processed_iot_readings (
  id SERIAL PRIMARY KEY,
  recorded_at TIMESTAMP,
  site TEXT,
  temperature_c FLOAT,
  humidity FLOAT,
  pm2_5 FLOAT,
  co_ppm FLOAT,
  vibration FLOAT,
  battery_pct FLOAT,
  temp_category TEXT,
  hour_of_day INT,
  day_of_week INT,
  rolling_avg_temp_7d FLOAT,
  temperature_c_norm FLOAT,
  humidity_norm FLOAT,
  pm2_5_norm FLOAT,
  co_ppm_norm FLOAT,
  vibration_norm FLOAT,
  battery_pct_norm FLOAT,
  processed_at TIMESTAMP DEFAULT NOW()
);
