# Reports & Diagrams

This folder stores generated plots and evaluation artifacts. The diagrams are created from the transformed dataset (`datasets/transformed_iot_readings.csv`) and saved as PNG files.

## Generate diagrams

```bash
python reports/generate_diagrams.py
```

### Options

- `--input`: Path to the transformed CSV (default: `datasets/transformed_iot_readings.csv`).
- `--output-dir`: Output directory for the PNG files (default: `reports`).
- `--max-sites`: Number of top sites to include in site-based plots (default: `6`).

## Expected outputs

- `reports/temperature_over_time_by_site.png`
- `reports/humidity_distribution_by_site.png`
- `reports/pm25_vs_temperature.png`
- `reports/battery_vs_vibration.png`
