"""Generate exploratory diagrams from the transformed IoT dataset."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


def _apply_style() -> None:
    try:
        plt.style.use("seaborn-v0_8")
    except OSError:
        pass


def load_data(csv_path: Path) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    df["recorded_at"] = pd.to_datetime(df["recorded_at"], errors="coerce")
    df = df.dropna(subset=["recorded_at", "site", "temperature_c"])
    return df


def plot_temperature_over_time_by_site(
    df: pd.DataFrame, output_dir: Path, max_sites: int
) -> Path:
    top_sites = df["site"].value_counts().head(max_sites).index
    subset = df[df["site"].isin(top_sites)].copy()
    subset["day"] = subset["recorded_at"].dt.to_period("D").dt.to_timestamp()

    daily = (
        subset.groupby(["day", "site"], as_index=False)["temperature_c"]
        .mean()
        .sort_values("day")
    )
    pivot = daily.pivot(index="day", columns="site", values="temperature_c")

    fig, ax = plt.subplots(figsize=(12, 6))
    for site in pivot.columns:
        ax.plot(pivot.index, pivot[site], label=site, linewidth=2)

    ax.set_title("Daily Average Temperature by Site")
    ax.set_xlabel("Date")
    ax.set_ylabel("Temperature (°C)")
    ax.legend(title="Site", ncol=2, fontsize=9)
    ax.grid(True, linestyle="--", alpha=0.3)

    output_path = output_dir / "temperature_over_time_by_site.png"
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)
    return output_path


def plot_humidity_distribution_by_site(
    df: pd.DataFrame, output_dir: Path, max_sites: int
) -> Path:
    top_sites = df["site"].value_counts().head(max_sites).index
    subset = df[df["site"].isin(top_sites)]

    fig, ax = plt.subplots(figsize=(10, 6))
    data = [subset[subset["site"] == site]["humidity"] for site in top_sites]
    ax.boxplot(data, tick_labels=top_sites, showfliers=False)
    ax.set_title("Humidity Distribution by Site")
    ax.set_xlabel("Site")
    ax.set_ylabel("Humidity (%)")
    ax.tick_params(axis="x", rotation=30)
    ax.grid(axis="y", linestyle="--", alpha=0.3)

    output_path = output_dir / "humidity_distribution_by_site.png"
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)
    return output_path


def plot_pm25_vs_temperature(df: pd.DataFrame, output_dir: Path) -> Path:
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(
        df["pm2_5"],
        df["temperature_c"],
        alpha=0.35,
        s=22,
        color="#dd8452",
    )
    ax.set_title("PM2.5 vs Temperature")
    ax.set_xlabel("PM2.5")
    ax.set_ylabel("Temperature (°C)")
    ax.grid(True, linestyle="--", alpha=0.3)

    output_path = output_dir / "pm25_vs_temperature.png"
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)
    return output_path


def plot_battery_vs_vibration(df: pd.DataFrame, output_dir: Path) -> Path:
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(
        df["battery_pct"],
        df["vibration"],
        alpha=0.4,
        s=22,
        color="#55a868",
    )
    ax.set_title("Battery Level vs Vibration")
    ax.set_xlabel("Battery (%)")
    ax.set_ylabel("Vibration")
    ax.grid(True, linestyle="--", alpha=0.3)

    output_path = output_dir / "battery_vs_vibration.png"
    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)
    return output_path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Generate IoT diagrams from transformed dataset."
    )
    parser.add_argument(
        "--input",
        type=Path,
    default=Path("datasets/transformed_iot_readings.csv"),
        help="Path to transformed CSV input.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("reports"),
        help="Directory to write PNG diagrams.",
    )
    parser.add_argument(
    "--max-sites",
        type=int,
        default=6,
        help="Number of top sites to include in site-based plots.",
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    _apply_style()
    output_dir = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    df = load_data(args.input)
    outputs = [
        plot_temperature_over_time_by_site(df, output_dir, args.max_sites),
        plot_humidity_distribution_by_site(df, output_dir, args.max_sites),
        plot_pm25_vs_temperature(df, output_dir),
        plot_battery_vs_vibration(df, output_dir),
    ]

    print("Generated diagrams:")
    for path in outputs:
        print(f" - {path}")


if __name__ == "__main__":
    main()
