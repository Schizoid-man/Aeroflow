"""Dataset preparation script for synthetic IoT readings."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from pipeline.iot_stream import generate_synthetic_readings


LOGGER_NAME: str = "setup.download_datasets"


def _get_logger() -> logging.Logger:
    """Create or return the module logger."""

    logger = logging.getLogger(LOGGER_NAME)
    if not logger.handlers:
        handler = logging.StreamHandler()
        fmt = logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
        )
        handler.setFormatter(fmt)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


def _ensure_sample_csv(data_dir: Path) -> None:
    """Create a synthetic IoT sample CSV for offline/CI runs."""

    logger = _get_logger()
    sample_path = data_dir / "sample_iot_readings.csv"
    if sample_path.exists():
        return

    df = generate_synthetic_readings(count=300)
    df.to_csv(sample_path, index=False)
    logger.info("Created synthetic IoT sample CSV at %s", sample_path)


def main(*, project_root: Optional[Path] = None) -> None:
    """Run downloads and prepare datasets."""

    root = project_root or Path(__file__).resolve().parents[1]
    data_dir = root / "datasets"
    data_dir.mkdir(parents=True, exist_ok=True)

    _ensure_sample_csv(data_dir)


if __name__ == "__main__":
    main()
