# AeroPulse — IoT Sensor Streaming & Predictive Maintenance Pipeline

> An end-to-end data engineering and ML pipeline that ingests synthetic + MQTT IoT sensor streams, transforms them through a validated ETL process, warehouses them in PostgreSQL, and trains a regression model to forecast temperature drift — orchestrated with Apache Airflow and validated through GitHub Actions CI/CD.

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Architecture](#2-architecture)
3. [Tech Stack](#3-tech-stack)
4. [Repository Structure](#4-repository-structure)
5. [Data Sources](#5-data-sources)
6. [Pipeline Stages](#6-pipeline-stages)
7. [Machine Learning](#7-machine-learning)
8. [Airflow DAGs](#8-airflow-dags)
9. [Database Schema](#9-database-schema)
10. [Setup & Installation](#10-setup--installation)
11. [Running the Pipeline](#11-running-the-pipeline)
12. [Testing](#12-testing)
13. [CI/CD Pipeline](#13-cicd-pipeline)
14. [Configuration Reference](#14-configuration-reference)
15. [Future Scope](#15-future-scope)

---

## 1. Project Overview

AeroPulse is a production-style data engineering system for real-time IoT monitoring and predictive maintenance in industrial sites. The system:

- **Extracts** synthetic IoT readings and optional MQTT streams (temperature, humidity, vibration, air quality).
- **Transforms** raw data through cleaning, deduplication, feature engineering (temperature categories, time features, 7-day rolling averages), and MinMax normalization.
- **Loads** both raw and processed records into a PostgreSQL data warehouse.
- **Trains** a `RandomForestRegressor` on processed features to predict temperature drift.
- **Evaluates** the model and generates metrics (`MAE`, `RMSE`, `R²`) and a scatter plot of actual vs. predicted values.
- **Orchestrates** all stages via Apache Airflow DAGs with daily ETL and weekly ML training schedules.
- **Validates** every commit through a three-stage GitHub Actions CI/CD workflow.

---

## 2. Architecture

```
┌──────────────────────────────────────────────────────────┐
│                     Streaming Sources                    │
│                                                          │
│  ┌────────────────┐   ┌───────────────────────────────┐ │
│  │ Synthetic IoT  │   │ MQTT Broker (optional stream) │ │
│  │ Generator      │   │ aeropulse/iot/readings         │ │
│  └──────┬─────────┘   └───────────────┬───────────────┘ │
└─────────┼─────────────────────────────┼─────────────────┘
          └─────────────────────────────┼─────────────────┘
                                        │ Extract & Unify
                                 ┌──────▼──────┐
                                 │   Extract   │  pipeline/extract.py
                                 └──────┬──────┘
                                        │ Validate raw shape
                                 ┌──────▼──────┐
                                 │  Transform  │  pipeline/transform.py
                                 │  + Validate │  (clean, engineer, normalise)
                                 └──────┬──────┘
                                        │
                            ┌───────────┴───────────┐
                            │                       │
                     ┌──────▼──────┐         ┌──────▼──────┐
                     │  Load Raw   │         │ Load Proc.  │  pipeline/load.py
                     │ raw_iot_    │         │ processed_  │
                     │ readings    │         │ iot_readings│
                     └──────┬──────┘         └──────┬──────┘
                            └───────────┬───────────┘
                                        │  PostgreSQL 15
                                 ┌──────▼──────┐
                                 │  ML Train   │  forecasting/train.py
                                 │  (RF Model) │
                                 └──────┬──────┘
                                        │
                                 ┌──────▼──────┐
                                 │  Evaluate   │  forecasting/evaluate.py
                                 │  + Report   │  (MAE / RMSE / R² / plot)
                                 └─────────────┘
```

**Orchestration:** Both pipelines are managed as Airflow DAGs.  
**CI/CD:** GitHub Actions runs lint → test → pipeline validation → simulated deploy on every push.

---

## 3. Tech Stack

| Component | Tool / Library | Version |
|---|---|---|
| Orchestration | Apache Airflow | 2.8.0 |
| Data Warehouse | PostgreSQL | 15 |
| Data Processing | pandas | 2.1.0 / 2.2.2 |
| Numerical Computing | NumPy | 1.26.0 |
| DB Connectivity | SQLAlchemy + psycopg2-binary | 2.0.30 / 2.9.9 |
| ML Framework | scikit-learn | 1.3.0 / 1.5.0 |
| Model Serialisation | joblib | 1.4.2 |
| Visualisation | matplotlib | 3.7.0 / 3.8.4 |
| MQTT Client | paho-mqtt | 1.6.1 |
| Config Management | python-dotenv | 1.0.0 |
| Testing | pytest + pytest-cov | 7.4.0 / 4.1.0 |
| Linting | flake8 | 6.1.0 |
| Containerisation | Docker + Docker Compose | — |
| CI/CD | GitHub Actions | — |

> Version variants reflect Python 3.10 / 3.12 compatibility pins in `requirements.txt`.

---

## 4. Repository Structure

```
AeroPulse/
│
├── pipeline/                   # Core ETL modules
│   ├── extract.py              # Ingest from synthetic CSV + optional MQTT
│   ├── transform.py            # Clean, engineer features, normalise
│   ├── load.py                 # Write raw + processed data to PostgreSQL
│   └── iot_stream.py           # IoT generator + MQTT helpers
│
├── forecasting/                # ML training & evaluation
│   ├── train.py                # RandomForestRegressor training
│   ├── evaluate.py             # Metrics (MAE/RMSE/R²) + scatter plot
│   └── model/                  # Saved model artefact (gitignored)
│
├── orchestration/              # Airflow DAG definitions
│   ├── etl_pipeline_dag.py     # Daily ETL DAG (extract→transform→load)
│   └── ml_training_dag.py      # Weekly ML DAG (train→evaluate→save)
│
├── quality_assurance/          # pytest unit tests
│   ├── test_extract.py
│   ├── test_transform.py
│   └── test_load.py
│
├── schema/                     # PostgreSQL DDL + analytics queries
│   ├── create_tables.sql
│   └── queries.sql
│
├── settings/                   # Database connection utilities
│   └── db_config.py            # Reads .env → DBConfig dataclass
│
├── setup/                      # Dataset bootstrapping
│   └── download_datasets.py    # Auto-downloads sample data if missing
│
├── datasets/                   # Local data files (synthetic CSV)
│   └── sample_iot_readings.csv
│
├── .github/workflows/
│   └── ci_cd_pipeline.yml      # GitHub Actions: lint → test → validate → deploy
│
├── logs/                       # Runtime logs (gitignored)
├── reports/                    # Generated plots (gitignored)
│
├── Dockerfile.airflow          # Custom Airflow image
├── docker-compose.yml          # Airflow webserver + scheduler + PostgreSQL
├── requirements.txt            # Python dependencies
├── pytest.ini                  # Test discovery configuration
└── .flake8                     # Linting configuration
```

---

## 5. Data Sources

| Source | Type | Description |
|---|---|---|
| **Synthetic IoT Generator** | Local | Creates realistic sensor readings (temperature, humidity, vibration, air quality) on demand. |
| **MQTT Broker (optional)** | Live / Stream | Subscribes to `aeropulse/iot/readings` and collects messages into the batch ETL window. |
| **CSV (`sample_iot_readings.csv`)** | Static / Local | Offline sample dataset with columns: `recorded_at`, `device_id`, `site`, `temperature_c`, `humidity`, `pm2_5`, `co_ppm`, `vibration`, `battery_pct`, `source`. |

All sources are unified into a single wide DataFrame with a `source` column (`'csv'` or `'mqtt'`) before transformation.

---

## 6. Pipeline Stages

### Extract (`pipeline/extract.py`)

- Calls `run_extraction()` to pull from the synthetic CSV and (optionally) MQTT.
- MQTT is enabled when `MQTT_BROKER` is set, otherwise it stays offline-only.
- Serialises output to JSON for Airflow XCom transfer (`df_to_xcom_json` / `df_from_xcom_json`).
- CLI usage: `python pipeline/extract.py [--use-mqtt] [--out PATH]`

### Transform (`pipeline/transform.py`)

Performs the following in sequence:

1. **Type coercion** — parses `recorded_at`, `temperature_c`, `humidity` with error handling.
2. **Deduplication** — drops rows with the same `(recorded_at, device_id, site)` triple.
3. **Feature engineering:**
       - `temp_category` — maps temperature to: `Cool` / `Normal` / `Hot`.
       - `hour_of_day`, `day_of_week` — extracted from timestamp.
       - `rolling_avg_temp_7d` — 7-day rolling mean of temperature, grouped by site.
4. **Normalisation** — MinMax scaling of sensor columns (`temperature_c`, `humidity`, `pm2_5`, `co_ppm`, `vibration`, `battery_pct`) to `[0, 1]`.
5. **Validation** — asserts required columns exist, no nulls in critical fields (`temperature_c`, `humidity`, `site`, `recorded_at`), and normalised values are within `[0, 1]`. Results logged to `logs/validation_log.txt`.

CLI usage: `python pipeline/transform.py [--input PATH] [--output PATH]`

### Load (`pipeline/load.py`)

- Creates PostgreSQL tables via `schema/create_tables.sql` (uses an advisory transaction lock to prevent race conditions in parallel Airflow tasks).
- Appends data using `pandas.DataFrame.to_sql()` with `method="multi"` and `chunksize=500`.
- Loads into two tables: `raw_iot_readings` and `processed_iot_readings`.

---

## 7. Machine Learning

### Model

- **Algorithm:** `RandomForestRegressor` (scikit-learn)
- **Estimators:** 100 trees, `random_state=42`
- **Train/Test Split:** 80/20, deterministic (`random_state=42`)

### Features

| Feature | Description |
|---|---|
| `humidity_norm` | MinMax-normalised humidity |
| `pm2_5_norm` | MinMax-normalised PM2.5 concentration |
| `co_ppm_norm` | MinMax-normalised CO concentration |
| `vibration_norm` | MinMax-normalised vibration |
| `battery_pct_norm` | MinMax-normalised battery level |
| `hour_of_day` | Hour extracted from measurement timestamp |
| `day_of_week` | Day of week (0 = Monday) |
| `rolling_avg_temp_7d` | 7-day rolling mean temperature, per site |

**Target:** `temperature_c` (degrees Celsius)

### Training

```bash
# Train from PostgreSQL processed table
python forecasting/train.py
```

Model saved to `forecasting/model/temperature_model.pkl`.

### Evaluation

```bash
python forecasting/evaluate.py
```

Outputs:
- `logs/model_metrics.txt` — MAE, RMSE, R² scores
- `reports/actual_vs_predicted_temperature.png` — scatter plot with identity line

---

## 8. Airflow DAGs

### ETL DAG — `iot_stream_etl_pipeline`

**Schedule:** `@daily`

```
task_extract → task_validate_raw → task_transform → task_load_raw  ─┐
                                                                      → task_notify
                                                  → task_load_processed ─┘
```

| Task | Description |
|---|---|
| `task_extract` | Runs full extraction (synthetic CSV + optional MQTT), pushes JSON to XCom |
| `task_validate_raw` | Asserts required columns and non-empty dataset |
| `task_transform` | Runs transformation, pushes processed JSON to XCom |
| `task_load_raw` | Writes raw rows to `raw_iot_readings` |
| `task_load_processed` | Writes processed rows to `processed_iot_readings` |
| `task_notify` | Logs success summary with row counts |

### ML Training DAG — `iot_training_pipeline`

**Schedule:** `@weekly`

```
load_data_from_db → preprocess_features → train_model → evaluate_model → save_model
```

| Task | Description |
|---|---|
| `load_data_from_db` | Reads `processed_iot_readings` from PostgreSQL |
| `preprocess_features` | Builds feature matrix X and target y |
| `train_model` | Trains `RandomForestRegressor`, saves `.pkl` |
| `evaluate_model` | Computes MAE/RMSE/R², saves metrics and plot |
| `save_model` | Confirms model artefact path |

---

## 9. Database Schema

### `raw_iot_readings`

| Column | Type | Description |
|---|---|---|
| `id` | SERIAL PK | Auto-incrementing primary key |
| `recorded_at` | TIMESTAMP | Sensor timestamp |
| `device_id` | TEXT | Sensor identifier |
| `site` | TEXT | Facility or zone |
| `temperature_c` | FLOAT | Temperature in °C |
| `humidity` | FLOAT | Relative humidity (%) |
| `pm2_5` | FLOAT | Particulate concentration |
| `co_ppm` | FLOAT | CO concentration (ppm) |
| `vibration` | FLOAT | Vibration magnitude |
| `battery_pct` | FLOAT | Battery percentage |
| `source` | TEXT | Data origin: `csv` or `mqtt` |
| `ingested_at` | TIMESTAMP | Row insertion time (auto) |

### `processed_iot_readings`

| Column | Type | Description |
|---|---|---|
| `id` | SERIAL PK | Auto-incrementing primary key |
| `recorded_at` | TIMESTAMP | Sensor timestamp |
| `site` | TEXT | Facility or zone |
| `temperature_c` | FLOAT | Temperature in °C |
| `humidity` | FLOAT | Relative humidity (%) |
| `pm2_5` | FLOAT | Particulate concentration |
| `co_ppm` | FLOAT | CO concentration (ppm) |
| `vibration` | FLOAT | Vibration magnitude |
| `battery_pct` | FLOAT | Battery percentage |
| `temp_category` | TEXT | Category label (Cool → Hot) |
| `hour_of_day` | INT | Hour of day (0–23) |
| `day_of_week` | INT | Day of week (0–6) |
| `rolling_avg_temp_7d` | FLOAT | 7-day rolling temperature mean |
| `temperature_c_norm`, `humidity_norm`, `pm2_5_norm` | FLOAT | MinMax-normalised sensors |
| `processed_at` | TIMESTAMP | Row insertion time (auto) |

---

## 10. Setup & Installation

### Prerequisites

- Python 3.10+ (3.12 supported)
- Docker + Docker Compose (for Airflow orchestration)
- Optional MQTT broker access (only if you want live streaming)

### 1. Clone and install dependencies

```bash
git clone https://github.com/<your-org>/AeroPulse.git
cd AeroPulse

python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
```

> **Note:** `apache-airflow` is excluded from CI installs automatically. For local script runs without Docker, Airflow is not required.

### 2. Create the `.env` file

```env
# PostgreSQL connection (use 'localhost' when running scripts outside Docker)
DB_HOST=postgres
DB_PORT=5432
DB_USER=airflow
DB_PASSWORD=airflow
DB_NAME=airflow_aqi

# Airflow Fernet key (required for Docker Compose)
# Generate with: python -c "import base64, os; print(base64.urlsafe_b64encode(os.urandom(32)).decode())"
AIRFLOW_FERNET_KEY=<your-fernet-key>

# MQTT settings (optional — only needed for live streaming)
MQTT_BROKER=localhost
MQTT_TOPIC=aeropulse/iot/readings
MQTT_DURATION_SEC=10
MQTT_MAX_MESSAGES=200
```

### 3. Start Docker services (Airflow + PostgreSQL)

```bash
docker-compose up --build -d
```

### 4. Initialise Airflow

```bash
# Run inside the webserver container
docker-compose exec airflow-webserver airflow db migrate

docker-compose exec airflow-webserver airflow users create \
  --username admin --firstname Admin --lastname User \
  --role Admin --email admin@example.com --password admin
```

Airflow UI: **http://localhost:8080**

---

## 11. Running the Pipeline

### Run individual stages locally

```bash
# Extract (dry-run skips MQTT consumption)
python pipeline/extract.py --dry-run --out datasets/extracted_iot.csv

# Transform
python pipeline/transform.py --input datasets/sample_iot_readings.csv --output datasets/transformed_iot_readings.csv

# Train the model (requires PostgreSQL with processed data)
python forecasting/train.py

# Evaluate the model
python forecasting/evaluate.py
```

### Trigger the Airflow DAG

**From the UI:** Enable `iot_stream_etl_pipeline` → click **Trigger DAG**.

**From the CLI (inside the container):**

```bash
docker-compose exec airflow-webserver airflow dags trigger iot_stream_etl_pipeline
docker-compose exec airflow-webserver airflow dags trigger iot_training_pipeline
```

### Generate analysis diagrams

Use the transformed dataset to create quick visual summaries (stored in `reports/`).

```bash
python reports/generate_diagrams.py
```

---

## 12. Testing

Unit tests live in `quality_assurance/` and are discovered via `pytest.ini`.

```bash
# Run all tests
pytest -q

# Run with coverage report
pytest -q --cov=pipeline --cov=forecasting --cov-report=term-missing
```

### Test coverage

| Module | Tests |
|---|---|
| `pipeline/extract.py` | Synthetic IoT generation, CSV loading, optional MQTT ingestion |
| `pipeline/transform.py` | Null dropping, deduplication, temperature categorisation, normalisation bounds |
| `pipeline/load.py` | Column validation, prepared DataFrame shape |

---

## 13. CI/CD Pipeline

The GitHub Actions workflow (`.github/workflows/ci_cd_pipeline.yml`) runs on every push to `main` or `feature/*` branches, and on pull requests to `main`.

```
┌─────────────────────┐
│   lint_and_test     │  ← Always runs
│  ─ flake8 lint      │
│  ─ pytest + cov     │
│  ─ upload coverage  │
└──────────┬──────────┘
           │ on success
┌──────────▼──────────┐
│  validate_pipeline  │  ← Always runs (after lint_and_test)
│  ─ dry-run extract  │
│  ─ transform + col  │
│    assertion        │
└──────────┬──────────┘
           │ on success (main branch only)
┌──────────▼──────────┐
│    deploy_etl       │  ← main branch only
│  ─ simulated deploy │
└─────────────────────┘
```

| Job | Description |
|---|---|
| **lint_and_test** | Installs CI requirements (Airflow excluded), runs `flake8` on `pipeline/` and `forecasting/`, runs `pytest` with XML coverage upload. |
| **validate_pipeline** | Runs a dry-run extraction (no network calls), transforms sample CSV, asserts expected output columns are present. |
| **deploy_etl** | Simulates deployment. In production this step would trigger the Airflow REST API, push a Docker image, or deploy via SSH. |

---

## 14. Configuration Reference

| Environment Variable | Required | Default | Description |
|---|---|---|---|
| `DB_HOST` | Yes | — | PostgreSQL host (`postgres` in Docker, `localhost` locally) |
| `DB_PORT` | Yes | — | PostgreSQL port (usually `5432`) |
| `DB_USER` | Yes | — | Database username |
| `DB_PASSWORD` | Yes | — | Database password |
| `DB_NAME` | Yes | — | Database name |
| `MQTT_BROKER` | No | `localhost` | MQTT broker host for streaming ingestion |
| `MQTT_TOPIC` | No | `aeropulse/iot/readings` | MQTT topic to subscribe to |
| `MQTT_DURATION_SEC` | No | `10` | Seconds to listen for MQTT messages |
| `MQTT_MAX_MESSAGES` | No | `200` | Maximum MQTT messages to collect per run |
| `AIRFLOW_FERNET_KEY` | Yes (Docker) | — | Fernet key for Airflow connection encryption |

---

## 15. Future Scope

| Enhancement | Description |
|---|---|
| **Kafka Streaming** | Replace MQTT ingestion with Kafka topics for high-volume telemetry |
| **Cloud Data Warehouse** | Migrate PostgreSQL to Snowflake or BigQuery for scalable analytics |
| **ML Experiment Tracking** | Integrate MLflow for model versioning and experiment comparison |
| **Dashboard** | Build a Grafana or Streamlit dashboard over the IoT warehouse |
| **Predictive Maintenance** | Train models to predict battery drop or vibration anomalies |
| **Alerting** | Trigger notifications when temperature or vibration exceeds thresholds |

---

<div align="center">
  <sub>Built as part of CIE634 — Data Management for Machine Learning | M.Tech AI | Ramaiah Institute of Technology</sub>
</div>
