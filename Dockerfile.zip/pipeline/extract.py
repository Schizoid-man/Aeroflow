"""Extract IoT sensor readings from synthetic generator or MQTT stream."""

from __future__ import annotations

import argparse
import json
import logging
import os
from pathlib import Path
from typing import List, Optional

import pandas as pd

from pipeline.iot_stream import (
    DEFAULT_BROKER,
    DEFAULT_TOPIC,
    consume_readings_from_mqtt,
    generate_synthetic_readings,
)


LOGGER_NAME: str = "pipeline.extract"

PROJECT_ROOT: Path = Path(__file__).resolve().parents[1]
DATA_DIR: Path = PROJECT_ROOT / "datasets"
SAMPLE_CSV_PATH: Path = DATA_DIR / "sample_iot_readings.csv"

MQTT_BROKER_ENV: str = "MQTT_BROKER"
MQTT_TOPIC_ENV: str = "MQTT_TOPIC"
MQTT_DURATION_ENV: str = "MQTT_DURATION_SEC"
MQTT_MAX_MESSAGES_ENV: str = "MQTT_MAX_MESSAGES"

DEFAULT_MQTT_DURATION_SEC: int = 10
DEFAULT_MQTT_MAX_MESSAGES: int = 200

RAW_COLUMNS: List[str] = [
    "recorded_at",
    "device_id",
    "site",
    "temperature_c",
    "humidity",
    "pm2_5",
    "co_ppm",
    "vibration",
    "battery_pct",
    "source",
]


def _get_logger() -> logging.Logger:
    logger = logging.getLogger(LOGGER_NAME)
    if not logger.handlers:
        handler = logging.StreamHandler()
        fmt = logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
        )
        handler.setFormatter(fmt)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


def ensure_sample_dataset() -> None:
    """Ensure a local synthetic CSV dataset exists for offline runs."""

    logger = _get_logger()
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if SAMPLE_CSV_PATH.exists():
        return

    df = generate_synthetic_readings(count=300)
    df.to_csv(SAMPLE_CSV_PATH, index=False)
    logger.info("Created synthetic IoT sample at %s", SAMPLE_CSV_PATH)


def extract_from_csv(csv_path: Path) -> pd.DataFrame:
    """Load local CSV data for IoT readings."""

    ensure_sample_dataset()
    if not csv_path.exists():
        raise FileNotFoundError(f"CSV not found: {csv_path}")

    df = pd.read_csv(csv_path)
    missing = [c for c in RAW_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"CSV missing columns: {missing}")
    return df


def extract_from_mqtt(
    *,
    broker: str,
    topic: str,
    duration_sec: int,
    max_messages: int,
) -> pd.DataFrame:
    """Consume IoT readings from MQTT."""

    logger = _get_logger()
    try:
        df = consume_readings_from_mqtt(
            broker=broker,
            topic=topic,
            duration_sec=duration_sec,
            max_messages=max_messages,
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("MQTT consumption failed: %s", exc)
        return pd.DataFrame(columns=RAW_COLUMNS)

    if df.empty:
        return pd.DataFrame(columns=RAW_COLUMNS)

    if "source" not in df.columns:
        df["source"] = "mqtt"
    return df


def run_extraction(
    *,
    dry_run: bool = False,
    use_mqtt: Optional[bool] = None,
    csv_path: Optional[Path] = None,
    mqtt_duration_sec: Optional[int] = None,
    mqtt_max_messages: Optional[int] = None,
) -> pd.DataFrame:
    """Run extraction from local synthetic CSV plus optional MQTT stream."""

    logger = _get_logger()
    ensure_sample_dataset()

    csv_df = extract_from_csv(csv_path or SAMPLE_CSV_PATH).copy()
    csv_df["source"] = csv_df.get("source", "csv")

    mqtt_enabled = use_mqtt
    if mqtt_enabled is None:
        mqtt_enabled = bool(os.getenv(MQTT_BROKER_ENV))

    mqtt_df = pd.DataFrame(columns=RAW_COLUMNS)
    if mqtt_enabled and not dry_run:
        broker = os.getenv(MQTT_BROKER_ENV, DEFAULT_BROKER)
        topic = os.getenv(MQTT_TOPIC_ENV, DEFAULT_TOPIC)
        duration = int(
            mqtt_duration_sec
            or os.getenv(MQTT_DURATION_ENV, DEFAULT_MQTT_DURATION_SEC)
        )
        max_messages = int(
            mqtt_max_messages
            or os.getenv(MQTT_MAX_MESSAGES_ENV, DEFAULT_MQTT_MAX_MESSAGES)
        )
        mqtt_df = extract_from_mqtt(
            broker=broker,
            topic=topic,
            duration_sec=duration,
            max_messages=max_messages,
        )
        logger.info("MQTT extracted rows=%s", len(mqtt_df))

    merged = pd.concat([csv_df, mqtt_df], ignore_index=True)
    logger.info("Extraction completed rows=%s", len(merged))
    return merged


def df_to_xcom_json(df: pd.DataFrame) -> str:
    """Serialize DataFrame to JSON for Airflow XCom payloads."""

    return df.to_json(orient="records", date_format="iso")


def df_from_xcom_json(payload: str) -> pd.DataFrame:
    """Deserialize JSON payload back to DataFrame."""

    records = json.loads(payload)
    return pd.DataFrame.from_records(records)


def _parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extract IoT sensor readings"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Skip MQTT consumption (CI-safe).",
    )
    parser.add_argument(
        "--use-mqtt",
        action="store_true",
        help="Consume from MQTT in addition to local CSV.",
    )
    parser.add_argument(
        "--mqtt-duration",
        type=int,
        default=DEFAULT_MQTT_DURATION_SEC,
        help="Seconds to listen for MQTT messages.",
    )
    parser.add_argument(
        "--mqtt-max-messages",
        type=int,
        default=DEFAULT_MQTT_MAX_MESSAGES,
        help="Maximum MQTT messages to collect.",
    )
    parser.add_argument(
        "--out",
        default=str(DATA_DIR / "extracted_iot.csv"),
        help="Write extraction output CSV to this path.",
    )
    return parser.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = _parse_args(argv)
    df = run_extraction(
        dry_run=bool(args.dry_run),
        use_mqtt=bool(args.use_mqtt),
        mqtt_duration_sec=args.mqtt_duration,
        mqtt_max_messages=args.mqtt_max_messages,
    )
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_path, index=False)
    _get_logger().info("Wrote extraction output to %s", out_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
