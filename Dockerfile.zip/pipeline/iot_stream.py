"""Utilities for synthetic IoT data generation and MQTT streaming."""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from typing import Iterable, List, Optional

import numpy as np
import pandas as pd


DEFAULT_SITES = ["Plant-1", "Plant-2", "Warehouse-A", "Warehouse-B"]
DEFAULT_TOPIC = "aeropulse/iot/readings"
DEFAULT_BROKER = "localhost"


@dataclass
class IoTReading:
    recorded_at: str
    device_id: str
    site: str
    temperature_c: float
    humidity: float
    pm2_5: float
    co_ppm: float
    vibration: float
    battery_pct: float
    source: str


def generate_synthetic_readings(
    *,
    count: int = 500,
    device_count: int = 12,
    sites: Optional[List[str]] = None,
    start_time: Optional[datetime] = None,
    freq_minutes: int = 5,
    seed: int = 42,
    source: str = "synthetic",
) -> pd.DataFrame:
    """Create a synthetic IoT dataset with realistic sensor ranges."""

    rng = np.random.default_rng(seed)
    sites = sites or DEFAULT_SITES
    devices = [f"device-{idx:02d}" for idx in range(1, device_count + 1)]

    if start_time is None:
        start_time = datetime.now(timezone.utc) - timedelta(
            minutes=freq_minutes * count
        )

    timestamps = [
        start_time + timedelta(minutes=freq_minutes * i) for i in range(count)
    ]
    device_choices = rng.choice(devices, size=count)
    site_choices = rng.choice(sites, size=count)

    temperature = rng.normal(loc=24.0, scale=4.5, size=count)
    humidity = rng.normal(loc=58.0, scale=12.0, size=count)
    pm2_5 = rng.gamma(shape=2.0, scale=8.0, size=count)
    co_ppm = rng.normal(loc=0.6, scale=0.2, size=count)
    vibration = rng.normal(loc=0.25, scale=0.1, size=count)
    battery = rng.uniform(35, 100, size=count)

    df = pd.DataFrame(
        {
            "recorded_at": [ts.isoformat() for ts in timestamps],
            "device_id": device_choices,
            "site": site_choices,
            "temperature_c": temperature.clip(5, 45),
            "humidity": humidity.clip(15, 95),
            "pm2_5": pm2_5.clip(0, 200),
            "co_ppm": co_ppm.clip(0.1, 2.5),
            "vibration": vibration.clip(0.01, 1.0),
            "battery_pct": battery.clip(5, 100),
            "source": source,
        }
    )
    return df


def readings_from_dataframe(df: pd.DataFrame) -> Iterable[IoTReading]:
    for _, row in df.iterrows():
        yield IoTReading(
            recorded_at=str(row["recorded_at"]),
            device_id=str(row["device_id"]),
            site=str(row["site"]),
            temperature_c=float(row["temperature_c"]),
            humidity=float(row["humidity"]),
            pm2_5=float(row["pm2_5"]),
            co_ppm=float(row["co_ppm"]),
            vibration=float(row["vibration"]),
            battery_pct=float(row["battery_pct"]),
            source=str(row.get("source", "synthetic")),
        )


def publish_readings_to_mqtt(
    df: pd.DataFrame,
    *,
    broker: str = DEFAULT_BROKER,
    topic: str = DEFAULT_TOPIC,
    delay_sec: float = 0.0,
) -> None:
    """Publish readings to an MQTT broker as JSON payloads."""

    try:
        import paho.mqtt.client as mqtt
    except ImportError as exc:
        raise RuntimeError("paho-mqtt is required for MQTT publishing") from exc

    client = mqtt.Client()
    client.connect(broker)
    client.loop_start()

    for reading in readings_from_dataframe(df):
        client.publish(topic, json.dumps(asdict(reading)))
        if delay_sec > 0:
            time.sleep(delay_sec)

    client.loop_stop()
    client.disconnect()


def consume_readings_from_mqtt(
    *,
    broker: str = DEFAULT_BROKER,
    topic: str = DEFAULT_TOPIC,
    duration_sec: int = 10,
    max_messages: int = 200,
) -> pd.DataFrame:
    """Consume MQTT messages and return them as a DataFrame."""

    try:
        import paho.mqtt.client as mqtt
    except ImportError as exc:
        raise RuntimeError("paho-mqtt is required for MQTT consumption") from exc

    messages: List[dict] = []

    def on_message(_client, _userdata, msg):
        if len(messages) >= max_messages:
            return
        try:
            payload = json.loads(msg.payload.decode("utf-8"))
            if isinstance(payload, dict):
                messages.append(payload)
        except json.JSONDecodeError:
            return

    client = mqtt.Client()
    client.on_message = on_message
    client.connect(broker)
    client.subscribe(topic)
    client.loop_start()

    time.sleep(duration_sec)

    client.loop_stop()
    client.disconnect()

    return pd.DataFrame(messages)
