"""ETL package for IoT streaming pipeline."""
