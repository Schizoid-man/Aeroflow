"""Transform and validate synthetic IoT sensor readings."""

from __future__ import annotations

import argparse
import logging
from pathlib import Path
from typing import List, Optional

import pandas as pd
from sklearn.preprocessing import MinMaxScaler


LOGGER_NAME: str = "pipeline.transform"
PROJECT_ROOT: Path = Path(__file__).resolve().parents[1]
LOG_DIR: Path = PROJECT_ROOT / "logs"
VALIDATION_LOG_PATH: Path = LOG_DIR / "validation_log.txt"

CRITICAL_COLS: List[str] = ["temperature_c", "humidity", "site", "recorded_at"]
SENSOR_COLS: List[str] = [
    "temperature_c",
    "humidity",
    "pm2_5",
    "co_ppm",
    "vibration",
    "battery_pct",
]
NORM_SUFFIX: str = "_norm"


def _get_logger() -> logging.Logger:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(LOGGER_NAME)
    if not logger.handlers:
        handler = logging.FileHandler(VALIDATION_LOG_PATH, encoding="utf-8")
        fmt = logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
        )
        handler.setFormatter(fmt)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


def temp_to_category(temp_c: float) -> str:
    if temp_c <= 18:
        return "Cool"
    if temp_c <= 27:
        return "Normal"
    return "Hot"


def run_transformation(df: pd.DataFrame) -> pd.DataFrame:
    logger = _get_logger()
    df_work = df.copy()

    for col in ["device_id", "site", "source"]:
        if col in df_work.columns:
            df_work[col] = df_work[col].astype(str).str.strip()

    if "recorded_at" not in df_work.columns:
        if "date" in df_work.columns:
            df_work["recorded_at"] = pd.to_datetime(
                df_work["date"], errors="coerce"
            )
        else:
            raise ValueError("Missing recorded_at column")
    else:
        df_work["recorded_at"] = pd.to_datetime(
            df_work["recorded_at"], errors="coerce"
        )

    for col in SENSOR_COLS:
        if col in df_work.columns:
            df_work[col] = pd.to_numeric(df_work[col], errors="coerce")

    df_work = df_work.dropna(subset=["recorded_at", "site", "temperature_c"])
    df_work = df_work.drop_duplicates(
        subset=["recorded_at", "device_id", "site"]
    )

    df_work["temp_category"] = df_work["temperature_c"].apply(temp_to_category)
    df_work["hour_of_day"] = df_work["recorded_at"].dt.hour.astype(int)
    df_work["day_of_week"] = df_work["recorded_at"].dt.dayofweek.astype(int)

    df_work = df_work.sort_values(["site", "recorded_at"]).reset_index(drop=True)
    df_work["rolling_avg_temp_7d"] = (
        df_work.set_index("recorded_at")
        .groupby("site")["temperature_c"]
        .rolling("7D", min_periods=1)
        .mean()
        .reset_index(level=0, drop=True)
        .astype(float)
    )

    scaler = MinMaxScaler()
    cols_for_scaling = [c for c in SENSOR_COLS if c in df_work.columns]
    if cols_for_scaling:
        scaled = scaler.fit_transform(df_work[cols_for_scaling].fillna(0.0))
        for idx, col in enumerate(cols_for_scaling):
            df_work[f"{col}{NORM_SUFFIX}"] = scaled[:, idx]

    _validate(df_work, logger)
    logger.info("Transformation successful; rows=%s", len(df_work))
    return df_work


def _validate(df: pd.DataFrame, logger: logging.Logger) -> None:
    expected_cols = set(
        [
            "recorded_at",
            "site",
            "temperature_c",
            "humidity",
            "pm2_5",
            "co_ppm",
            "vibration",
            "battery_pct",
            "temp_category",
            "hour_of_day",
            "day_of_week",
            "rolling_avg_temp_7d",
        ]
    )
    missing = sorted(list(expected_cols - set(df.columns)))
    if missing:
        msg = f"Missing expected columns after transform: {missing}"
        logger.error(msg)
        raise ValueError(msg)

    nulls = {
        col: int(df[col].isna().sum()) for col in CRITICAL_COLS if col in df
    }
    logger.info("Null counts (critical): %s", nulls)
    if any(v > 0 for v in nulls.values()):
        msg = f"Nulls remain in critical columns: {nulls}"
        logger.error(msg)
        raise ValueError(msg)

    norm_cols = [c for c in df.columns if c.endswith(NORM_SUFFIX)]
    if norm_cols:
        min_val = float(df[norm_cols].min().min())
        max_val = float(df[norm_cols].max().max())
        logger.info(
            "Normalized value range: min=%s max=%s", min_val, max_val
        )
        if min_val < 0.0 - 1e-9 or max_val > 1.0 + 1e-9:
            msg = "Normalized columns contain values outside [0, 1]"
            logger.error(msg)
            raise ValueError(msg)


def _parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Transform IoT dataset")
    parser.add_argument(
        "--input",
        default=str(PROJECT_ROOT / "datasets" / "sample_iot_readings.csv"),
        help="Input CSV path.",
    )
    parser.add_argument(
        "--output",
        default=str(PROJECT_ROOT / "datasets" / "transformed_iot_readings.csv"),
        help="Output CSV path.",
    )
    return parser.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = _parse_args(argv)
    df_in = pd.read_csv(args.input)
    df_out = run_transformation(df_in)
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df_out.to_csv(out_path, index=False)
    logging.getLogger(LOGGER_NAME).info(
        "Wrote transformed dataset to %s", out_path
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
